# 15331416 赵寒旭 数字图像处理Hw1
## 文件结构
* Image_hw1: eclipse java项目代码包
----bin
----src
----input_Img
----quantized_Img
----scaled_Img

* Runner jar: 可直接运行jar包
----ImageProcessing.jar
注：运行后生成两个文件夹:
----quantized_Img
----scaled_Img

* 15331416_hw1_report.pdf

* README.md

## 项目运行方式
cd Image_hw1/Runner jar
java -jar ImageProcessing.jar
